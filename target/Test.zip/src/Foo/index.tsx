import React, { useState, useCallback } from 'react';
import { ConfigProvider } from 'antd';
import { Test } from 'xone-design';

const Foo = () => {
  const [num, setNum] = useState(1);

  const onChangeNum = useCallback(() => {
    setNum((prev) => prev + 1);
  }, []);

  return (
    <div>
      <ConfigProvider prefixCls="xod-ant">
        <Test num={num} onChangeNum={onChangeNum} />
      </ConfigProvider>
    </div>
  )
}

export default Foo;
