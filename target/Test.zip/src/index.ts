import 'xone-design/dist/index.esm.css';
import 'antd/dist/antd.css';

export { default as Foo } from './Foo';
