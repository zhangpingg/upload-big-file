export declare class Base {
}
