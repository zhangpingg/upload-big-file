import { Hasher } from '../lib/Hasher';
import { WordArray } from '../lib/WordArray';
export declare class SHA256 extends Hasher {
    _hash: WordArray;
    reset(): void;
    _doProcessBlock(M: Array<number>, offset: number): void;
    _doFinalize(): WordArray;
}
