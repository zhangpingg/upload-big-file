import { Hasher } from '../lib/Hasher';
import { WordArray } from '../lib/WordArray';
export declare class MD5 extends Hasher {
    _hash: WordArray;
    static FF(a: number, b: number, c: number, d: number, x: number, s: number, t: number): number;
    static GG(a: number, b: number, c: number, d: number, x: number, s: number, t: number): number;
    static HH(a: number, b: number, c: number, d: number, x: number, s: number, t: number): number;
    static II(a: number, b: number, c: number, d: number, x: number, s: number, t: number): number;
    reset(): void;
    _doProcessBlock(M: Array<number>, offset: number): void;
    _doFinalize(): WordArray;
}
