import { BlockCipherMode } from './BlockCipherMode';
/**
 * Cipher Block Chaining mode.
 */
export declare abstract class CBC extends BlockCipherMode {
    static Encryptor: any;
    static Decryptor: any;
}
