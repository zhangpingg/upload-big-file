import { BlockCipherMode } from './BlockCipherMode';
import { ECBEncryptor } from './ECBEncryptor';
import { ECBDecryptor } from './ECBDecryptor';
/**
 * Cipher Block Chaining mode.
 */
export declare abstract class ECB extends BlockCipherMode {
    static Encryptor: typeof ECBEncryptor;
    static Decryptor: typeof ECBDecryptor;
}
