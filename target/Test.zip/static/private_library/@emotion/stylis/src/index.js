// @flow
export { default } from './stylis.min'
